package com.example.cookit.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.cookit.R
import com.example.cookit.fragments.HomeFragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer,HomeFragment()).commit()

    }
}